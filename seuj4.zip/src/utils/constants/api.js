export const SECRET_KEY = "18eae32c-c2f0-4a8e-bed2-766f67be042f";
